classdef CrankAngleResolvedEngineInput < handle
%% Class implementation of Input Signal Builder

% You can use this class to load input signals for
% crank-angle-resolved engine example.
% The model has From Workspace blocks which read InputSignals and
% InputBus in the base workspace.
%{
data = CrankAngleResolvedEngineInput().EngineStart;
InputSignals = data.Signals;
InputBus = data.Bus;
set_param(bdroot, StopTime=num2str(data.Options.StopTime_s))
%}
% You can plot the signals, for example using stackedplot as follows.
%{
figure
stackedplot( ...
  InputSignals.StarterOnOff, ...
  InputSignals.IgnitorOnOff, ...
  InputSignals.Throttle, ...
  InputSignals.AirFuelRatio, ...
  InputSignals.SparkAngleBTDC, ...
  InputSignals.DynoBrakeTorque, ...
  LineWidth=2, LegendVisible='off' )
%}

% Copyright 2022 The MathWorks, Inc.

properties
  % Signals

  StarterOnOff timetable
  IgnitorOnOff timetable
  Throttle timetable
  AirFuelRatio timetable
  SparkAngleBTDC timetable
  DynoBrakeTorque timetable

  % Other properties

  FunctionName (1,1) string
  StopTime (1,1) duration

  ParentFigure (1,1)  % must be of type matlab.ui.Figure
  Plot_tf (1,1) logical = false
  VisiblePlot_tf (1,1) logical = true
  FigureWidth (1,1) double = 600
  FigureHeight (1,1) double = 600
  LineWidth (1,1) double = 2
end

methods

  function inpObj = CrankAngleResolvedEngineInput(nvpairs)
  %%
    arguments
      nvpairs.Plot_tf
      nvpairs.FigureWidth
      nvpairs.FigureHeight
      nvpairs.LineWidth
    end
    if isfield(nvpairs, 'Plot_tf'), inpObj.Plot_tf = nvpairs.Plot_tf; end
    if isfield(nvpairs, 'FigureWidth'), inpObj.FigureWidth = nvpairs.FigureWidth; end
    if isfield(nvpairs, 'FigureHeight'), inpObj.FigureHeight = nvpairs.FigureHeight; end
    if isfield(nvpairs, 'LineWidth'), inpObj.LineWidth = nvpairs.LineWidth; end

    % Default signals are created in the constructor so that
    % the plotSignals function works right after creating a class object.
    tmp = inpObj.Plot_tf;
    inpObj.Plot_tf = false;
    Constant(inpObj);
    inpObj.Plot_tf = tmp;
  end

  %% Signal Patterns

  function signalData = Constant(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.StopTime (1,1) duration = seconds(600)
      nvpairs.StarterOnOff (1,1) {mustBeMember(nvpairs.StarterOnOff, [0 1])} = 1
      nvpairs.IgnitorOnOff (1,1) {mustBeMember(nvpairs.IgnitorOnOff, [0 1])} = 1
      nvpairs.Throttle (1,1) {mustBeInRange(nvpairs.Throttle, 0, 1)} = 0.3
      nvpairs.AirFuelRatio (1,1) {mustBeInRange(nvpairs.AirFuelRatio, 0, 40)} = 14.6
      nvpairs.SparkAngleBTDC (1,1) {mustBeInRange(nvpairs.SparkAngleBTDC, -90, 90)} = 20
      nvpairs.DynoBrakeTorque (1,1) {mustBeInRange(nvpairs.DynoBrakeTorque, -1000, 1000)} = 5
      nvpairs.InitialEngineSpeed_rpm (1,1) {mustBeInRange(nvpairs.InitialEngineSpeed_rpm, 0, 15000)} = 1200
    end

    % Record the function name. This is used for the plot window title.
    ds = dbstack;
    thisFunctionFullName = ds(1).name;
    inpObj.FunctionName = extractAfter(thisFunctionFullName, ".");

    inpObj.StopTime = nvpairs.StopTime;
    t_end = seconds(nvpairs.StopTime);

    x1 = nvpairs.StarterOnOff;
    BuildSignal_StarterOnOff(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.IgnitorOnOff;
    BuildSignal_IgnitorOnOff(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.Throttle;
    BuildSignal_Throttle(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.AirFuelRatio;
    BuildSignal_AirFuelRatio(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.SparkAngleBTDC;
    BuildSignal_SparkAngleBTDC(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.DynoBrakeTorque;
    BuildSignal_DynoBrakeTorque(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    if inpObj.Plot_tf
      plotSignals(inpObj);
    end

    signalData = BundleSignals(inpObj);

    signalData.Options.InitialEngineSpeed_rpm = nvpairs.InitialEngineSpeed_rpm;

  end  % function

  function signalData = EngineStart(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.StopTime (1,1) duration = seconds(4)
      nvpairs.Throttle_1 (1,1) {mustBeInRange(nvpairs.Throttle_1, 0, 1)} = 0.6
      nvpairs.Throttle_2 (1,1) {mustBeInRange(nvpairs.Throttle_2, 0, 1)} = 0.05
      nvpairs.AirFuelRatio (1,1) {mustBeInRange(nvpairs.AirFuelRatio, 0, 40)} = 14.6
      nvpairs.SparkAngleBTDC (1,1) {mustBeInRange(nvpairs.SparkAngleBTDC, -90, 90)} = 20
      nvpairs.DynoBrakeTorque_1 (1,1) {mustBeInRange(nvpairs.DynoBrakeTorque_1, -1000, 1000)} = 0
      nvpairs.DynoBrakeTorque_2 (1,1) {mustBeInRange(nvpairs.DynoBrakeTorque_2, -1000, 1000)} = 3
      nvpairs.InitialEngineSpeed_rpm (1,1) {mustBeInRange(nvpairs.InitialEngineSpeed_rpm, 0, 15000)} = 0

      nvpairs.ThrottleChange_StartTime (1,1) duration = seconds(1.2)
      nvpairs.ThrottleChange_EndTime (1,1) duration = seconds(1.5)

      nvpairs.BrakeChange_StartTime (1,1) duration = seconds(1.5)
      nvpairs.BrakeChange_EndTime (1,1) duration = seconds(1.8)
    end

    % Record the function name. This is used for the plot window title.
    ds = dbstack;
    thisFunctionFullName = ds(1).name;
    inpObj.FunctionName = extractAfter(thisFunctionFullName, ".");

    inpObj.StopTime = nvpairs.StopTime;
    t_end = seconds(nvpairs.StopTime);

    BuildSignal_StarterOnOff(inpObj, Data=[0 1 0 0], Time=seconds([0 1 1.5 t_end]));

    BuildSignal_IgnitorOnOff(inpObj, Data=[0 1 1], Time=seconds([0 1.3 t_end]));

    x1 = nvpairs.Throttle_1;
    x2 = nvpairs.Throttle_2;
    t1 = seconds(nvpairs.ThrottleChange_StartTime);
    t2 = seconds(nvpairs.ThrottleChange_EndTime);
    assert(0.1 < t1)
    assert(t1 < t2)
    assert(t2+0.1 < t_end)
    BuildSignal_Throttle(inpObj, Data= [x1 x1  x1 x2 x2     x2], ...
                          Time=seconds([0  0.1 t1 t2 t2+0.1 t_end]));

    x1 = nvpairs.AirFuelRatio;
    BuildSignal_AirFuelRatio(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.SparkAngleBTDC;
    BuildSignal_SparkAngleBTDC(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.DynoBrakeTorque_1;
    x2 = nvpairs.DynoBrakeTorque_2;
    t1 = seconds(nvpairs.BrakeChange_StartTime);
    t2 = seconds(nvpairs.BrakeChange_EndTime);
    assert(0.1 < t1)
    assert(t1 < t2)
    assert(t2+0.1 < t_end)
    BuildSignal_DynoBrakeTorque(inpObj, Data= [x1 x1  x1 x2 x2     x2], ...
                                 Time=seconds([0  0.1 t1 t2 t2+0.1 t_end]));

    if inpObj.Plot_tf
      plotSignals(inpObj);
    end

    signalData = BundleSignals(inpObj);

    signalData.Options.InitialEngineSpeed_rpm = nvpairs.InitialEngineSpeed_rpm;

  end  % function

  function signalData = EngineStartStopStart(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.InitialEngineSpeed_rpm (1,1) {mustBeInRange(nvpairs.InitialEngineSpeed_rpm, 0, 15000)} = 0
      nvpairs.AirFuelRatio (1,1) {mustBeInRange(nvpairs.AirFuelRatio, 0, 40)} = 14.6
      nvpairs.SparkAngleBTDC (1,1) {mustBeInRange(nvpairs.SparkAngleBTDC, -90, 90)} = 20

      nvpairs.Throttle_1 (1,1) {mustBeInRange(nvpairs.Throttle_1, 0, 1)} = 0.6
      nvpairs.Throttle_2 (1,1) {mustBeInRange(nvpairs.Throttle_2, 0, 1)} = 0.05
      nvpairs.Throttle_3 (1,1) {mustBeInRange(nvpairs.Throttle_3, 0, 1)} = 0.6
      nvpairs.Throttle_4 (1,1) {mustBeInRange(nvpairs.Throttle_4, 0, 1)} = 0.05
      nvpairs.Throttle_5 (1,1) {mustBeInRange(nvpairs.Throttle_5, 0, 1)} = 0.6

      nvpairs.DynoBrakeTorque_1 (1,1) {mustBeInRange(nvpairs.DynoBrakeTorque_1, -1000, 1000)} = 0
      nvpairs.DynoBrakeTorque_2 (1,1) {mustBeInRange(nvpairs.DynoBrakeTorque_2, -1000, 1000)} = 3
      nvpairs.DynoBrakeTorque_3 (1,1) {mustBeInRange(nvpairs.DynoBrakeTorque_3, -1000, 1000)} = 0
      nvpairs.DynoBrakeTorque_4 (1,1) {mustBeInRange(nvpairs.DynoBrakeTorque_4, -1000, 1000)} = 3

      nvpairs.ThrottleChange_1_StartTime (1,1) duration = seconds(1.2)
      nvpairs.ThrottleChange_1_EndTime (1,1) duration = seconds(1.5)
      nvpairs.ThrottleChange_2_StartTime (1,1) duration = seconds(3.5)
      nvpairs.ThrottleChange_2_EndTime (1,1) duration = seconds(3.7)
      nvpairs.ThrottleChange_3_StartTime (1,1) duration = seconds(5)
      nvpairs.ThrottleChange_3_EndTime (1,1) duration = seconds(5.5)
      nvpairs.ThrottleChange_4_StartTime (1,1) duration = seconds(7.5)
      nvpairs.ThrottleChange_4_EndTime (1,1) duration = seconds(7.8)

      nvpairs.BrakeChange_1_StartTime (1,1) duration = seconds(1.5)
      nvpairs.BrakeChange_1_EndTime (1,1) duration = seconds(1.8)
      nvpairs.BrakeChange_2_StartTime (1,1) duration = seconds(3.5)
      nvpairs.BrakeChange_2_EndTime (1,1) duration = seconds(3.8)
      nvpairs.BrakeChange_3_StartTime (1,1) duration = seconds(5)
      nvpairs.BrakeChange_3_EndTime (1,1) duration = seconds(5.5)

      nvpairs.StopTime (1,1) duration = seconds(8)
    end

    % Record the function name. This is used for the plot window title.
    ds = dbstack;
    thisFunctionFullName = ds(1).name;
    inpObj.FunctionName = extractAfter(thisFunctionFullName, ".");

    inpObj.StopTime = nvpairs.StopTime;
    t_end = seconds(nvpairs.StopTime);

    x1 = nvpairs.AirFuelRatio;
    BuildSignal_AirFuelRatio(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    x1 = nvpairs.SparkAngleBTDC;
    BuildSignal_SparkAngleBTDC(inpObj, Data=[x1 x1], Time=seconds([0 t_end]));

    BuildSignal_StarterOnOff(inpObj, ...
      Data=        [0 1 0   1 0   0], ...
      Time=seconds([0 1 1.5 5 5.5 t_end]));

    BuildSignal_IgnitorOnOff( inpObj, ...
      Data=        [0 1   0   1   0   0], ...
      Time=seconds([0 1.3 3.5 5.3 7.5 t_end]));

    x1 = nvpairs.Throttle_1;
    x2 = nvpairs.Throttle_2;
    x3 = nvpairs.Throttle_3;
    x4 = nvpairs.Throttle_4;
    x5 = nvpairs.Throttle_5;
    t1 = seconds(nvpairs.ThrottleChange_1_StartTime);
    t2 = seconds(nvpairs.ThrottleChange_1_EndTime);
    t3 = seconds(nvpairs.ThrottleChange_2_StartTime);
    t4 = seconds(nvpairs.ThrottleChange_2_EndTime);
    t5 = seconds(nvpairs.ThrottleChange_3_StartTime);
    t6 = seconds(nvpairs.ThrottleChange_3_EndTime);
    t7 = seconds(nvpairs.ThrottleChange_4_StartTime);
    t8 = seconds(nvpairs.ThrottleChange_4_EndTime);
    assert(0.1 < t1)
    assert(t1 < t2)
    assert(t2+0.1 < t3)
    assert(t3 < t4)
    assert(t4+0.1 < t5)
    assert(t5 < t6)
    assert(t6+0.1 < t7)
    assert(t7 < t8)
    assert(t8+0.1 < t_end)
    BuildSignal_Throttle( inpObj, ...
      Data=        [x1 x1  x1 x2 x2     x2 x3 x3     x3 x4 x4     x4 x5 x5     x5], ...
      Time=seconds([0  0.1 t1 t2 t2+0.1 t3 t4 t4+0.1 t5 t6 t6+0.1 t7 t8 t8+0.1 t_end]));

    x1 = nvpairs.DynoBrakeTorque_1;
    x2 = nvpairs.DynoBrakeTorque_2;
    x3 = nvpairs.DynoBrakeTorque_3;
    x4 = nvpairs.DynoBrakeTorque_4;
    t1 = seconds(nvpairs.BrakeChange_1_StartTime);
    t2 = seconds(nvpairs.BrakeChange_1_EndTime);
    t3 = seconds(nvpairs.BrakeChange_2_StartTime);
    t4 = seconds(nvpairs.BrakeChange_2_EndTime);
    t5 = seconds(nvpairs.BrakeChange_3_StartTime);
    t6 = seconds(nvpairs.BrakeChange_3_EndTime);
    assert(0.1 < t1)
    assert(t1 < t2)
    assert(t2+0.1 < t_end)
    assert(t2+0.1 < t3)
    assert(t3 < t4)
    assert(t4+0.1 < t5)
    assert(t5 < t6)
    assert(t6+0.1 < t_end)
    BuildSignal_DynoBrakeTorque( inpObj, ...
      Data=        [x1 x1  x1 x2 x2     x2 x3 x3     x3 x4 x4     x4], ...
      Time=seconds([0  0.1 t1 t2 t2+0.1 t3 t4 t4+0.1 t5 t6 t6+0.1 t_end]));

    if inpObj.Plot_tf
      plotSignals(inpObj);
    end

    signalData = BundleSignals(inpObj);

    signalData.Options.InitialEngineSpeed_rpm = nvpairs.InitialEngineSpeed_rpm;

  end  % function

end  % methods

methods (Access = private)

  function signalData = BundleSignals(inpObj)
  %%
    signalData.Signals.StarterOnOff = inpObj.StarterOnOff;
    signalData.Signals.IgnitorOnOff = inpObj.IgnitorOnOff;
    signalData.Signals.Throttle = inpObj.Throttle;
    signalData.Signals.AirFuelRatio = inpObj.AirFuelRatio;
    signalData.Signals.SparkAngleBTDC = inpObj.SparkAngleBTDC;
    signalData.Signals.DynoBrakeTorque = inpObj.DynoBrakeTorque;

    signalData.Bus = Simulink.Bus;
    sigs = {
      inpObj.StarterOnOff ...
      inpObj.IgnitorOnOff ...
      inpObj.Throttle ...
      inpObj.AirFuelRatio ...
      inpObj.SparkAngleBTDC ...
      inpObj.DynoBrakeTorque };
    for i = 1:numel(sigs)
      signalData.Bus.Elements(i) = Simulink.BusElement;
      signalData.Bus.Elements(i).Name = sigs{i}.Properties.VariableNames{1};
      signalData.Bus.Elements(i).Unit = sigs{i}.Properties.VariableUnits{1};
    end

    % Additional data to return
    opts.FunctionName = inpObj.FunctionName;
    opts.StopTime_s = seconds(inpObj.StopTime);
    opts.TimeStamp = string(datetime("now", "Format","yyyy-MM-dd HH:mm:ss"));

    if isprop(inpObj, 'ParentFigure')
      opts.ParentFigure = inpObj.ParentFigure;
    end

    signalData.Options = opts;
  end  % function

  %% Build signal trace with timetable

  function inpObj = BuildSignal_StarterOnOff(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.Data (:,1) double
      nvpairs.Time (:,1) duration
      nvpairs.TimeStep (1,1) duration = seconds(0.01)
    end
    inpObj.StarterOnOff = timetable(nvpairs.Data, 'RowTimes',nvpairs.Time);
    inpObj.StarterOnOff.Properties.VariableNames = {'StarterOnOff'};
    inpObj.StarterOnOff.Properties.VariableUnits = {'1'};
    inpObj.StarterOnOff.Properties.VariableContinuity = {'step'};
  end

  function inpObj = BuildSignal_IgnitorOnOff(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.Data (:,1) double
      nvpairs.Time (:,1) duration
      nvpairs.TimeStep (1,1) duration = seconds(0.01)
    end
    inpObj.IgnitorOnOff = timetable(nvpairs.Data, 'RowTimes',nvpairs.Time);
    inpObj.IgnitorOnOff.Properties.VariableNames = {'IgnitorOnOff'};
    inpObj.IgnitorOnOff.Properties.VariableUnits = {'1'};
    inpObj.IgnitorOnOff.Properties.VariableContinuity = {'step'};
  end

  function inpObj = BuildSignal_Throttle(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.Data (:,1) double
      nvpairs.Time (:,1) duration
      nvpairs.TimeStep (1,1) duration = seconds(0.01)
    end
    inpObj.Throttle = timetable(nvpairs.Data, 'RowTimes',nvpairs.Time);
    inpObj.Throttle.Properties.VariableNames = {'Throttle'};
    inpObj.Throttle.Properties.VariableUnits = {'1'};
    inpObj.Throttle.Properties.VariableContinuity = {'continuous'};
    inpObj.Throttle = ...
      retime(inpObj.Throttle, 'regular','makima', 'TimeStep',nvpairs.TimeStep);
  end

  function inpObj = BuildSignal_AirFuelRatio(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.Data (:,1) double
      nvpairs.Time (:,1) duration
      nvpairs.TimeStep (1,1) duration = seconds(0.01)
    end
    inpObj.AirFuelRatio = timetable(nvpairs.Data, 'RowTimes',nvpairs.Time);
    inpObj.AirFuelRatio.Properties.VariableNames = {'AirFuelRatio'};
    inpObj.AirFuelRatio.Properties.VariableUnits = {'1'};
    inpObj.AirFuelRatio.Properties.VariableContinuity = {'continuous'};
    inpObj.AirFuelRatio = ...
      retime(inpObj.AirFuelRatio, 'regular','makima', 'TimeStep',nvpairs.TimeStep);
  end

  function inpObj = BuildSignal_SparkAngleBTDC(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.Data (:,1) double
      nvpairs.Time (:,1) duration
      nvpairs.TimeStep (1,1) duration = seconds(0.01)
    end
    inpObj.SparkAngleBTDC = timetable(nvpairs.Data, 'RowTimes',nvpairs.Time);
    inpObj.SparkAngleBTDC.Properties.VariableNames = {'SparkAngleBTDC'};
    inpObj.SparkAngleBTDC.Properties.VariableUnits = {'deg'};
    inpObj.SparkAngleBTDC.Properties.VariableContinuity = {'continuous'};
    inpObj.SparkAngleBTDC = ...
      retime(inpObj.SparkAngleBTDC, 'regular','makima', 'TimeStep',nvpairs.TimeStep);
  end

  function inpObj = BuildSignal_DynoBrakeTorque(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.Data (:,1) double
      nvpairs.Time (:,1) duration
      nvpairs.TimeStep (1,1) duration = seconds(0.01)
    end
    inpObj.DynoBrakeTorque = timetable(nvpairs.Data, 'RowTimes',nvpairs.Time);
    inpObj.DynoBrakeTorque.Properties.VariableNames = {'DynoBrakeTorque'};
    inpObj.DynoBrakeTorque.Properties.VariableUnits = {'N*m'};
    inpObj.DynoBrakeTorque.Properties.VariableContinuity = {'continuous'};
    inpObj.DynoBrakeTorque = ...
      retime(inpObj.DynoBrakeTorque, 'regular','makima', 'TimeStep',nvpairs.TimeStep);
  end

  function plotSignals(inpObj, nvpairs)
  %%
    arguments
      inpObj
      nvpairs.ParentFigure (1,1)
    end

    syncedInputs = synchronize( ...
      inpObj.StarterOnOff, ...
      inpObj.IgnitorOnOff, ...
      inpObj.Throttle, ...
      inpObj.AirFuelRatio, ...
      inpObj.SparkAngleBTDC, ...
      inpObj.DynoBrakeTorque );

    addUnitString = @(tt) ...
      string(tt.Properties.VariableNames) ...
        + " (" + string(tt.Properties.VariableUnits) + ")";

    dispLbl = { ...
      addUnitString(inpObj.StarterOnOff), ...
      addUnitString(inpObj.IgnitorOnOff), ...
      addUnitString(inpObj.Throttle), ...
      addUnitString(inpObj.AirFuelRatio), ...
      addUnitString(inpObj.SparkAngleBTDC), ...
      addUnitString(inpObj.DynoBrakeTorque) };

    if not(inpObj.VisiblePlot_tf)
      % Invisible figure.
      inpObj.ParentFigure = figure('Visible', 'off');
    elseif isfield(nvpairs, 'ParentFigure')
      % This function's ParentFigure option is specified.
      assert(isa(nvpairs.ParentFigure, 'matlab.ui.Figure'))
      inpObj.ParentFigure = nvpairs.ParentFigure;
    else
      % Create a new figure.
      inpObj.ParentFigure = figure;  % Do not use 'Visible','on'
    end

    % Show pattern name in the window title.
    inpObj.ParentFigure.Name = inpObj.FunctionName;

    stk = stackedplot( inpObj.ParentFigure, syncedInputs );
    stk.LineWidth = inpObj.LineWidth;
    stk.GridVisible = 'on';
    stk.DisplayLabels = dispLbl;
    % stackedplot does not have Interpreter=off setting for the title.
    % To prevent '_' from being interpreted as a subscript directive,
    % replace it with a space.
    % Note that title() does not work with stackedplot either.
    stk.Title = strrep(inpObj.FunctionName, '_', ' ');

    % Making the figure taller than the default plot window height can
    % make the top part of the window go outside the monitor screen.
    % To prevent it, lower the y position of the window,
    % assuming that lowering the window position is safer
    % because the visibility of the window top is more important
    % that of the window bottom.
    pos = inpObj.ParentFigure.Position;
    h_orig = pos(4);
    w = inpObj.FigureWidth;
    h_new = inpObj.FigureHeight;
    inpObj.ParentFigure.Position = [pos(1), pos(2)-(h_new-h_orig), w, h_new];
  end  % function

end  % methods
end  % classdef
