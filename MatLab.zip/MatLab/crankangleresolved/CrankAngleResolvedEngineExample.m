%% Crank-Angle-Resolved Engine Model
%
% This example shows a 2.0-liter, four-cylinder, naturally aspirated,
% spark-ignited, four-stroke engine which computes crank-angle-resolved
% instantaneous torque.
%
% To start the engine from the rest, first a starter motor starts rotating
% the crank wheel, followed by fuel injection and spark ignition to start
% firing. When combustion produces more torque at the crank than the
% starter motor torque, one-way clutch (also called overruning clutch)
% in the starter prevents the transmission of torque from crank to starter.
% Once the crank gets enough rotational momentum from successive
% combustions, starter motor is turned off and engine continues to
% operate by injection and spark.
%
% The engine torque can be controlled by varying throttle, air-fuel ratio,
% and spark timing.
%

% Copyright 2020-2025 The MathWorks, Inc.

%% Model

open_system('CrankAngleResolvedEngine')

%% Simulation Results

CrankAngleResolvedEnginePlot;

%%

