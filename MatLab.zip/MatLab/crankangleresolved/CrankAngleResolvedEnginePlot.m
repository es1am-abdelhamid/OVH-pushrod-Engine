% Code to plot simulation results from CrankAngleResolvedEngine
%% Plot Description:
%
% These plots show the brake torque and engine speed.

% Copyright 2019-2020 The MathWorks, Inc.

sdl_carem_tmp_modelname = 'CrankAngleResolvedEngine';
if not(bdIsLoaded(sdl_carem_tmp_modelname)), open_system(sdl_carem_tmp_modelname); end
sdl_carem_tmp_in = local_function_setup_simulation(sdl_carem_tmp_modelname);

% Generate simulation results if they don't exist
if ~exist('sdl_carem_tmp_out', 'var')
    sdl_carem_tmp_out = sim(sdl_carem_tmp_in);
end
clear sdl_carem_tmp_modelname sdl_carem_tmp_in

sdl_carem_tmp_plot_inputs = local_function_plot_inputs(sdl_carem_tmp_out, "topleft");
sdl_carem_tmp_plot_rpm_trq = local_function_plot_rpm_trq(sdl_carem_tmp_out, "topright");
sdl_carem_tmp_plot_pressures = local_function_plot_pressures(sdl_carem_tmp_out, "bottomleft");

%% Local Functions

function fobj = local_function_plot_inputs(out, winpos)
%%
    t = out.tout;
    StarterOnOff = out.logsout.get('<StarterOnOff>').Values.Data;
    IgnitionOnOff = out.logsout.get('<IgnitorOnOff>').Values.Data;
    DynoBrake = out.logsout.get('<DynoBrakeTorque>').Values.Data;
    SparkAngle = out.logsout.get('<SparkAngleBTDC>').Values.Data;
    AFR = out.logsout.get('<AirFuelRatio>').Values.Data;
    Accel = out.logsout.get('<Throttle>').Values.Data;

    p = local_function_winpos(winpos);
    fobj = figure('OuterPosition', [p.left, p.bottom, p.width, p.height]);
    fobj.MenuBar='none';  fobj.ToolBar='none';
    fobj.Name = 'CrankAngleResolvedEngineInputs';

    tl = tiledlayout(fobj, 5, 1);
    tl.TileSpacing = 'compact';
    tl.Padding = 'compact';

    ax = nexttile;  hold on;  grid on
    plot(ax, t, StarterOnOff, "LineWidth",2.5)
    plot(ax, t, IgnitionOnOff, "LineWidth",1.5)
    tmp = gca;  tmp.XTickLabel = '';
    title('Starter (blue) and Ignitor (red) On/Off')

    ax = nexttile;  hold on;  grid on
    plot(ax, t, SparkAngle, "LineWidth",1.5)
    tmp = gca;  tmp.XTickLabel = '';
    yMinRange = 2;
    y_mean = (max(SparkAngle) + min(SparkAngle)) / 2;
    plot(ax, xlim, [y_mean - yMinRange/2, y_mean + yMinRange/2], LineStyle="none", Marker="none")
    title('Spark Angle [BTDC]')

    ax = nexttile;  hold on;  grid on
    plot(ax, t, AFR, "LineWidth",1.5)
    tmp = gca;  tmp.XTickLabel = '';
    yMinRange = 2;
    y_mean = (max(AFR) + min(AFR)) / 2;
    plot(ax, xlim, [y_mean - yMinRange/2, y_mean + yMinRange/2], LineStyle="none", Marker="none")
    title('Air-to-Fuel Ratio')

    ax = nexttile;  hold on;  grid on
    plot(ax, t, Accel, "LineWidth",1.5)
    tmp = gca;  tmp.XTickLabel = '';
    yMinRange = 0.2;
    y_mean = (max(Accel) + min(Accel)) / 2;
    plot(ax, xlim, [max(0, y_mean - yMinRange/2), y_mean + yMinRange/2], LineStyle="none", Marker="none")
    title('Accelaration Pedal Angle [0-1]')

    ax = nexttile;  hold on;  grid on
    plot(ax, t, DynoBrake, "LineWidth",1.5)
    yMinRange = 2;
    y_mean = (max(DynoBrake) + min(DynoBrake)) / 2;
    plot(ax, xlim, [y_mean - yMinRange/2, y_mean + yMinRange/2], LineStyle="none", Marker="none")
    title('Dyno Brake Torque [N*m]')

    xlabel(tl, 'Time (s)')
    ylabel(tl, 'Inputs')
    linkaxes(ax, 'x')
end

function fobj = local_function_plot_rpm_trq(out, winpos)
%%
    t = out.tout;
    rpm_ave = out.logsout.get('Cycle-average engine speed').Values.Data;
    rpm_raw = out.logsout.get('Engine speed').Values.Data;
    engine_torque = out.logsout.get('Engine torque').Values.Data;
    brake_torque = out.logsout.get('Dyno brake torque').Values.Data;

    p = local_function_winpos(winpos);
    fobj = figure('OuterPosition', [p.left, p.bottom, p.width, p.height]);
    fobj.MenuBar='none';  fobj.ToolBar='none';
    fobj.Name = 'CrankAngleResolvedEngine Speed & Torque';

    tl = tiledlayout(fobj, 2, 1);
    tl.TileSpacing = 'compact';
    tl.Padding = 'compact';

    ax = nexttile;  hold on;  grid on
    plot(ax, t, rpm_raw, "LineWidth",2.5)
    plot(ax, t, rpm_ave, "LineWidth",1.5)
    tmp = gca;  tmp.XTickLabel = '';
    title('Instantaneous (blue) and Cycle-Average (red) Engine Speeds [rpm]')

    ax = nexttile;  hold on;  grid on
    plot(ax, t, engine_torque, "LineWidth",2.5);
    plot(ax, t, brake_torque, "LineWidth",1.5);
    title('Engine (blue) and Brake (red) Torques [N*m]')

    xlabel(tl, 'Time (s)')
    ylabel(tl, 'Outputs')
    linkaxes(ax, 'x')
end

function fobj = local_function_plot_pressures(out, winpos)
    t = out.tout;
    Pcyl_kPa_1 = out.logsout.get('Cylinder pressure').Values.Data(:,1);
    Pcyl_kPa_2 = out.logsout.get('Cylinder pressure').Values.Data(:,2);
    Pcyl_kPa_3 = out.logsout.get('Cylinder pressure').Values.Data(:,3);
    Pcyl_kPa_4 = out.logsout.get('Cylinder pressure').Values.Data(:,4);

    p = local_function_winpos(winpos);
    fobj = figure('OuterPosition', [p.left, p.bottom, p.width, p.height]);
    fobj.MenuBar='none';  fobj.ToolBar='none';
    fobj.Name = 'CrankAngleResolvedEngine Cylinder Pressures';

    tl = tiledlayout(fobj, 3, 1);
    tl.TileSpacing = 'compact';
    tl.Padding = 'compact';

    t_range = t>2.5 & t<3.5;
    ax = nexttile;  hold on;  grid on
    plot(ax, t(t_range), Pcyl_kPa_1(t_range)/1000, "LineWidth",2)
    title('#1 Cylinder Pressure [MPa]')

    t_range = t>2.95 & t<3.05;
    ax = nexttile;  hold on;  grid on
    plot(ax, t(t_range), Pcyl_kPa_1(t_range)/1000, "LineWidth",2)
    plot(ax, t(t_range), Pcyl_kPa_2(t_range)/1000, "LineWidth",2)
    plot(ax, t(t_range), Pcyl_kPa_3(t_range)/1000, "LineWidth",2)
    plot(ax, t(t_range), Pcyl_kPa_4(t_range)/1000, "LineWidth",2)
    title('All Cylinder Pressures [MPa]')

    ax = nexttile;  hold on;  grid on
    plot(ax, t(t_range), Pcyl_kPa_4(t_range), "LineWidth",2)
    title('#4 Cylinder Pressure Near Ambient Pressure [kPa]')
    ylim(ax, [0 500])

    xlabel(tl, 'Time (s)')
    ylabel(tl, 'Outputs')
    linkaxes(ax, 'x')
end

function in = local_function_setup_simulation(model_name)
    in = Simulink.SimulationInput(model_name);
    
    in = in.setModelParameter( ...
            'SimscapeLogOpenViewer', 'off', ...
            'EnablePacing', 'off', ...
            'SolverType', 'Variable-step', ...
            'Solver', 'VariableStepAuto', ...
            ...
            'SaveTime', 'on', ...
            'TimeSaveName', 'tout', ...
            ...
            'SignalLogging', 'on', ...
            'SignalLoggingName', 'logsout', ...
            ...
            'SimscapeLogType', 'local', ...
            'SimscapeLogSimulationStatistics', 'off', ...
            ... %'SimscapeLogToSDI', 'on', ...
            'SimscapeLogName', 'logsoutssc', ...
            'SimscapeLogDecimation', 1, ...
            'SimscapeLogLimitData', 'off', ...
            ...
            'ReturnWorkspaceOutputs', 'on', ...
            'ReturnWorkspaceOutputsName', 'out' );
end

function pos = local_function_winpos(location)
    % Positions of 2x2 Figure windows. Only used when this script is run
    % programatically.
    set(0, 'units','pixels')
    scr = get(0, 'screensize');
    screen_height = scr(4);
    
    fig_width = 480;
    fig_height = 340;
    gap = 5;
    
    p.topL.left = gap;
    p.topL.bottom = screen_height - gap - fig_height;

    p.topR.left = p.topL.left + fig_width + gap;
    p.topR.bottom = p.topL.bottom;

    p.botL.left = gap;
    p.botL.bottom = screen_height - gap - fig_height - gap - fig_height;

    p.botR.left = p.topL.left + fig_width + gap;
    p.botR.bottom = p.botL.bottom;
    
    if location == "topleft"
      pos.left   = p.topL.left;
      pos.bottom = p.topL.bottom;
    elseif location == "topright"
      pos.left   = p.topR.left;
      pos.bottom = p.topR.bottom;
    elseif location == "bottomleft"
      pos.left   = p.botL.left;
      pos.bottom = p.botL.bottom;
    elseif location == "bottomright"
      pos.left   = p.botR.left;
      pos.bottom = p.botR.bottom;
    end
    pos.width = fig_width;
    pos.height = fig_height;
end  % function
