function [theta_TLU, radius_TLU, length_TLU] = CamshaftGenerateCamProfile(radius_min, radius_max, theta_constant, eccentricity)
% Code to generate 1D vectors for a cam profile for CamshaftExample
%% Function description:
% The cam has a minmium radius between -thetaC and thetaC degrees.
% From theta_constant to 180 degrees, the radius increases parabolically from radius_min to radius_max.
% From 180 to 360-theta_constant degrees, the radius decreases parabolically back to radius_min.
% Inputs:
% radius_min - Minimum radius [m]
% radius_max - Maximum radius [m]
% theta_constant - Radius is constant over [-thetaC, thetaC]
% eccentricity [m]
%
% Outputs:
% theta_TLU - angle [deg]
% radius_TLU - radius at each angle [m]
% length_TLU - Length between axis and cam follower at each angle

% Copyright 2025 The MathWorks, Inc.

theta_TLU = 0:1:359; % [deg]

A = (radius_max - radius_min) / (180 - theta_constant)^2; % Constant parameter for radius continuity at thetaC

% Initialize the radius vector
radius_TLU = zeros(1, length(theta_TLU));

for i = 1:length(theta_TLU)
    if theta_TLU(i)< theta_constant
        radius_TLU(i) = radius_min;
    elseif theta_TLU(i) < 180
        radius_TLU(i) = radius_min + A*(theta_TLU(i) - theta_constant)^2;
    elseif theta_TLU(i) < 360 - theta_constant
        radius_TLU(i) = radius_min + A*(360 - theta_TLU(i) - theta_constant)^2;
    else
        radius_TLU(i) = radius_min;
    end
end
length_TLU = sqrt(radius_TLU.^2 - eccentricity^2);

end