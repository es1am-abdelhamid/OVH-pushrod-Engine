% Code to plot a cam profile for Camshaft Example
%% Plot Description:
%
% This plot shows the radius versus angle for the camshaft based on 1D vectors
% that define the radius and angle.

% Copyright 2025 The MathWorks, Inc.

% Reuse figure if it exists, else create new figure
if ~exist('h1_Camshaft', 'var') || ...
        ~isgraphics(h1_Camshaft, 'figure')
    h1_Camshaft = figure('Name', 'Camshaft');
end
figure(h1_Camshaft)
clf(h1_Camshaft)

polarplot(deg2rad(theta_TLU), radius_TLU);
title('Cam Profile (m)');